#!/bin/bash

solcjs --abi 02-example.sol

solcjs --bin 02-example.sol

solcjs --abi --bin 02-example.sol
