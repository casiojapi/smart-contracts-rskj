#!/bin/bash

npm install --global solc@0.8.13
# output:
# + solc@0.8.13

solcjs --version
# output:
# 0.8.13+commit.abaa5c0e.Emscripten.clang
